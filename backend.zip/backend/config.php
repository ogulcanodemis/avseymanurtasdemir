<?php
// Veritabanı bağlantı ayarları
$host = 'localhost:3306';
$dbname = 'avseyman_admin_panel';
$username = 'avseyman_seyma_tasdemir';
$password = 'bWJzw8949bt3!';

try {
    // Önce veritabanı olmadan bağlantı dene
    $db = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Sonra veritabanını seç
    $db->exec("USE $dbname");
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // Detaylı hata bilgisi
    error_log("DB Error: " . $e->getMessage());
    die("Veritabanı bağlantı hatası: " . $e->getMessage() . " (Host: $host, User: $username, DB: $dbname)");
}

// Session ayarları
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Güvenlik ayarları
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');

// Timezone ayarı
date_default_timezone_set('Europe/Istanbul');
?>